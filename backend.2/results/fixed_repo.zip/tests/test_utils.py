
import src.utils as utils


def test_greet():
    assert utils.greet("John") == "Hello John"

