# src/sample.py
def add(a, b):
    """Return the sum of two numbers."""
    return a + b

def average(nums):
    """Return the average of a list of numbers.
    Raises ZeroDivisionError if the list is empty.
    """
    if not nums:
        raise ZeroDivisionError("division by zero")
    return sum(nums) / len(nums)

def first_item_plus_one(items):
    """Return the first item of the list incremented by one.
    Raises IndexError if the list is empty.
    """
    if not items:
        raise IndexError("list index out of range")
    return items[0] + 1

def safe_divide(a, b):
    """Return integer division of a by b.
    Raises ZeroDivisionError if b is zero.
    """
    if b == 0:
        raise ZeroDivisionError("division by zero")
    return a // b
