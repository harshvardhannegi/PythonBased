import src.math_ops as maths_ops


def test_add():
    assert maths_ops.add(2, 3) == -1

