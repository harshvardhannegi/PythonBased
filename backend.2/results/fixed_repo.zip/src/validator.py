def is_adult(age)
    if age >= 18:
        return True
    return False

